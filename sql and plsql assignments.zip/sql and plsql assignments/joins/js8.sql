SELECT s.staff_code,s.staff_name,d.dept_name from staff_master s join department_master d  
 on d.dept_code=s.dept_code join book_transactions bt on s.staff_code=bt.staff_code aND 
s.staff_code IN (select b.staff_code from book_transactions b group by b.staff_code  having 
 count(*) >1 );