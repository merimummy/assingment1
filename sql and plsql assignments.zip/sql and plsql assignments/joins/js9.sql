SELECT s.student_code,s.student_name,d.dept_name from student_master s join department_master d 
 on d.dept_code=s.dept_code AND s.dept_code=(select st.dept_code from student_master st 
 group by st.dept_code having count(*)=(select MAX(count(*)) from student_master sm group by sm.dept_code) );