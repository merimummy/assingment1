SELECT b.book_pub_author,b.book_name from  
book_master b where  
 book_pub_author IN(select p.book_pub_author from book_master p group by p.book_pub_author having count(*) >1) ;